import face_recognition
import cv2
import numpy as np
import csv
import os
from datetime import datetime
# taking input from webcam starts here

video_capture = cv2.VideoCapture(0)# we are writing the input as zero because we are taking the
                                    # input from default web cam

Narendra_image = face_recognition.load_image_file("D:\\student_images\\Narendra Modi.jpg")
Narendra_encoding = face_recognition.face_encodings(Narendra_image)[0]

sahil_image = face_recognition.load_image_file("D:\\student_images\\sahil.jpeg")
sahil_encoding = face_recognition.face_encodings(sahil_image)[0]

ratan_image = face_recognition.load_image_file("D:\\student_images\\Ratan_Tata.jpg")
ratan_encoding = face_recognition.face_encodings(ratan_image)[0]

dhoni_image = face_recognition.load_image_file("D:\\student_images\\MS_Dhoni.jpg")
dhoni_encoding = face_recognition.face_encodings(dhoni_image)[0]

ratan_image = face_recognition.load_image_file("D:\\student_images\\Ratan_Tata.jpg")
ratan_encoding = face_recognition.face_encodings(ratan_image)[0]


known_face_encoding = [
Narendra_encoding,
sahil_encoding,
dhoni_encoding,
ratan_encoding
]
known_faces_name = [
    "Modi",
    "sahil",
    "Dhoni",
    "Ratan_Tata"
]

students = known_faces_name.copy()



face_locations = []
face_encodings = []
face_names = []
s = True



now = datetime.now()
current_date = now.strftime("%Y-%m-%d")


f = open("D:\\" + current_date + '.csv' , 'w+' , newline='') # opening the new csv file for per day
lnwriter = csv.writer(f) #  class instances of csv writer




while True:
    signal , frame = video_capture.read() # extraction of video data
                                        # here signal data is useless for us
    small_frame = cv2.resize(frame,(0,0), fx = 0.25 ,fy = 0.25) # decreasing the size of input that is coming out
    rgb_small_frame = small_frame[:,:,::-1]


    if s:
        face_locations = face_recognition.face_locations(rgb_small_frame) # for detecting either face
                                                                # is there in encoding or not
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
        face_names = []

        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces(known_face_encoding, face_encoding)
            name = ""
            face_distance = face_recognition.face_distance(known_face_encoding , face_encoding)
            best_match_index = np.argmin(face_distance) # find out the best match
            if matches[best_match_index]:
                name = known_faces_name[best_match_index] # finding out the matched faces name



                # Updation of csv file starts here

                face_names.append(name)
                if name in known_faces_name:
                    if name in students:
                        students.remove(name) # second time after taking attendence we remove
                                            # the name of student from the list so that student
                                            # again come in front of web cam at same day then
                                            # attendence will not be taken again
                        print(students)
                        current_time = now.strftime("%H-%M-%S")
                        lnwriter.writerow([name ,current_time])

        cv2.imshow("Attendence System" , frame) #showing output to user
        if cv2.waitKey(1) & 0xFF== ord('q'):  # exit condition if q button is pressed
            break


video_capture.release()
cv2.destroyAllWindows()
f.close() # closing of csv file







